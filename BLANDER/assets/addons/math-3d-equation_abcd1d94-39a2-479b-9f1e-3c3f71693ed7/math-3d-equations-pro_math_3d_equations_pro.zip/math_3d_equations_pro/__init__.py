bl_info = {
    "name": "Math 3D Equations Pro (with Marching Cubes & Attractors)",
    "author": "Soroush & GPT",
    "version": (1, 3, 0),
    "blender": (3, 0, 0),
    "location": "View3D > N-panel > Math 3D",
    "description": "Create 3D curves, surfaces, implicit meshes and strange attractors from math equations",
    "category": "Add Mesh",
}

import bpy
from bpy.props import (
    StringProperty,
    FloatProperty,
    IntProperty,
    EnumProperty,
)
from bpy.types import PropertyGroup, Panel, Operator
import math

# جدول مثلث‌ها از فایل جداگانه (خودت ساختی: tri_table_py.py)
from .tri_table_py import TRI_TABLE

# =========================================================
# Safe eval environment
# =========================================================

SAFE_MATH_GLOBALS = {"__builtins__": {}}
for name in dir(math):
    if not name.startswith("_"):
        SAFE_MATH_GLOBALS[name] = getattr(math, name)
SAFE_MATH_GLOBALS["abs"] = abs


def eval_expr(expr, **local_vars):
    """Evaluate a math expression with restricted environment."""
    try:
        return eval(expr, SAFE_MATH_GLOBALS, local_vars)
    except Exception as e:
        raise ValueError(f"Error in expression '{expr}': {e}")


def locals_with_params(props, **kwargs):
    """Inject a, b, c parameters into local variables."""
    kwargs.setdefault("a", props.param_a)
    kwargs.setdefault("b", props.param_b)
    kwargs.setdefault("c", props.param_c)
    return kwargs


# =========================================================
# Marching Cubes edge table (standard)
# =========================================================

EDGE_TABLE = [
    0x000, 0x109, 0x203, 0x30a, 0x406, 0x50f, 0x605, 0x70c,
    0x80c, 0x905, 0xa0f, 0xb06, 0xc0a, 0xd03, 0xe09, 0xf00,
    0x190, 0x099, 0x393, 0x29a, 0x596, 0x49f, 0x795, 0x69c,
    0x99c, 0x895, 0xb9f, 0xa96, 0xd9a, 0xc93, 0xf99, 0xe90,
    0x230, 0x339, 0x033, 0x13a, 0x636, 0x73f, 0x435, 0x53c,
    0xa3c, 0xb35, 0x83f, 0x936, 0xe3a, 0xf33, 0xc39, 0xd30,
    0x3a0, 0x2a9, 0x1a3, 0x0aa, 0x7a6, 0x6af, 0x5a5, 0x4ac,
    0xbac, 0xaa5, 0x9af, 0x8a6, 0xfaa, 0xea3, 0xda9, 0xca0,
    0x460, 0x569, 0x663, 0x76a, 0x066, 0x16f, 0x265, 0x36c,
    0xc6c, 0xd65, 0xe6f, 0xf66, 0x86a, 0x963, 0xa69, 0xb60,
    0x5f0, 0x4f9, 0x7f3, 0x6fa, 0x1f6, 0x0ff, 0x3f5, 0x2fc,
    0xdfc, 0xcf5, 0xfff, 0xef6, 0x9fa, 0x8f3, 0xbf9, 0xaf0,
    0x650, 0x759, 0x453, 0x55a, 0x256, 0x35f, 0x055, 0x15c,
    0xe5c, 0xf55, 0xc5f, 0xd56, 0xa5a, 0xb53, 0x859, 0x950,
    0x7c0, 0x6c9, 0x5c3, 0x4ca, 0x3c6, 0x2cf, 0x1c5, 0x0cc,
    0xfcc, 0xec5, 0xdcf, 0xcc6, 0xbca, 0xac3, 0x9c9, 0x8c0,
    0x8c0, 0x9c9, 0xac3, 0xbca, 0xcc6, 0xdcf, 0xec5, 0xfcc,
    0x0cc, 0x1c5, 0x2cf, 0x3c6, 0x4ca, 0x5c3, 0x6c9, 0x7c0,
    0x950, 0x859, 0xb53, 0xa5a, 0xd56, 0xc5f, 0xf55, 0xe5c,
    0x15c, 0x055, 0x35f, 0x256, 0x55a, 0x453, 0x759, 0x650,
    0xaf0, 0xbf9, 0x8f3, 0x9fa, 0xef6, 0xfff, 0xcf5, 0xdfc,
    0x2fc, 0x3f5, 0x0ff, 0x1f6, 0x6fa, 0x7f3, 0x4f9, 0x5f0,
    0xb60, 0xa69, 0x963, 0x86a, 0xf66, 0xe6f, 0xd65, 0xc6c,
    0x36c, 0x265, 0x16f, 0x066, 0x76a, 0x663, 0x569, 0x460,
    0xca0, 0xda9, 0xea3, 0xfaa, 0x8a6, 0x9af, 0xaa5, 0xbac,
    0x4ac, 0x5a5, 0x6af, 0x7a6, 0x0aa, 0x1a3, 0x2a9, 0x3a0,
    0xd30, 0xc39, 0xf33, 0xe3a, 0x936, 0x83f, 0xb35, 0xa3c,
    0x53c, 0x435, 0x73f, 0x636, 0x13a, 0x033, 0x339, 0x230,
    0xe90, 0xf99, 0xc93, 0xd9a, 0xa96, 0xb9f, 0x895, 0x99c,
    0x69c, 0x795, 0x49f, 0x596, 0x29a, 0x393, 0x099, 0x190,
    0xf00, 0xe09, 0xd03, 0xc0a, 0xb06, 0xa0f, 0x905, 0x80c,
    0x70c, 0x605, 0x50f, 0x406, 0x30a, 0x203, 0x109, 0x000,
]


def vertex_interp(isolevel, p1, p2, valp1, valp2):
    """Linear interpolation of vertex on an edge."""
    if abs(isolevel - valp1) < 1e-8:
        return p1
    if abs(isolevel - valp2) < 1e-8:
        return p2
    if abs(valp1 - valp2) < 1e-8:
        return p1
    t = (isolevel - valp1) / (valp2 - valp1)
    return (
        p1[0] + t * (p2[0] - p1[0]),
        p1[1] + t * (p2[1] - p1[1]),
        p1[2] + t * (p2[2] - p1[2]),
    )


# =========================================================
# Properties
# =========================================================

class MathEquationProperties(PropertyGroup):
    equation_type: EnumProperty(
        name="Type",
        description="Type of equation to generate",
        items=[
            ('YFX', "Graph y=f(x)", "2D graph in XZ plane (z=f(x), y=0)"),
            ('SURFACE', "Surface z=f(x,y)", "Create mesh surface from z=f(x,y)"),
            ('CURVE', "Param Curve", "Create 3D curve from x(u), y(u), z(u)"),
            ('SURFACE_PARAM', "Param Surface", "Create mesh from x(u,v), y(u,v), z(u,v)"),
            ('IMPLICIT', "Implicit (Points)", "Point cloud approximation of F(x,y,z)=0"),
            ('IMPLICIT_MC', "Implicit (Marching Cubes)", "Mesh via marching cubes for F(x,y,z)=iso"),
            ('ATTRACTOR', "Strange Attractor", "Integrate predefined chaotic systems"),
        ],
        default='SURFACE'
    )

    # Parameters a, b, c (برای فرمول‌ها و همچنین پارامتر attractorها)
    param_a: FloatProperty(name="a", default=10.0, description="Generic parameter a (e.g. Lorenz sigma)")
    param_b: FloatProperty(name="b", default=28.0, description="Generic parameter b (e.g. Lorenz rho)")
    param_c: FloatProperty(name="c", default=2.667, description="Generic parameter c (e.g. Lorenz beta)")

    # Graph y=f(x)
    yfx_eq: StringProperty(
        name="f(x)=",
        default="sin(x)",
        description="Function of x (drawn as z=f(x) in XZ plane, y=0)"
    )

    # Shared ranges
    x_min: FloatProperty(name="X Min", default=-3.14)
    x_max: FloatProperty(name="X Max", default=3.14)
    y_min: FloatProperty(name="Y Min", default=-3.14)
    y_max: FloatProperty(name="Y Max", default=3.14)

    res_x: IntProperty(name="Res X", default=40, min=4, max=300)
    res_y: IntProperty(name="Res Y", default=40, min=4, max=300)

    # Surface z=f(x,y)
    surface_eq: StringProperty(
        name="z =",
        default="sin(x)*cos(y)",
        description="Equation for z in terms of x and y"
    )

    # Parametric curve x(u), y(u), z(u)
    curve_x: StringProperty(name="x(u)=", default="cos(u)")
    curve_y: StringProperty(name="y(u)=", default="sin(u)")
    curve_z: StringProperty(name="z(u)=", default="u/10")

    u_min: FloatProperty(name="u Min", default=0.0)
    u_max: FloatProperty(name="u Max", default=6.28318)
    res_u: IntProperty(name="Res U", default=100, min=4, max=2000)

    # Parametric surface x(u,v), y(u,v), z(u,v)
    surf_param_x: StringProperty(
        name="x(u,v)=",
        default="(1 + 0.5*cos(v))*cos(u)"
    )
    surf_param_y: StringProperty(
        name="y(u,v)=",
        default="(1 + 0.5*cos(v))*sin(u)"
    )
    surf_param_z: StringProperty(
        name="z(u,v)=",
        default="0.5*sin(v)"
    )

    v_min: FloatProperty(name="v Min", default=0.0)
    v_max: FloatProperty(name="v Max", default=6.28318)
    res_v: IntProperty(name="Res V", default=40, min=4, max=300)

    # Implicit F(x,y,z) = 0 (point cloud + MC)
    implicit_eq: StringProperty(
        name="F(x,y,z)=",
        default="x*x + y*y + z*z - 1",
        description="Implicit function F(x,y,z)"
    )

    z_min: FloatProperty(name="Z Min", default=-1.0)
    z_max: FloatProperty(name="Z Max", default=1.0)
    res_z: IntProperty(name="Res Z", default=30, min=4, max=200)

    iso_threshold: FloatProperty(
        name="Iso ε",
        default=0.05,
        min=0.0,
        description="|F| <= ε for point cloud"
    )

    iso_mc_level: FloatProperty(
        name="Iso level",
        default=0.0,
        description="F(x,y,z) = iso level for marching cubes"
    )

    # -------- Strange Attractors --------
    attractor_type: EnumProperty(
        name="Attractor",
        items=[
            ('LORENZ', "Lorenz", "Lorenz attractor (a=σ, b=ρ, c=β)"),
            ('ROSSLER', "Rössler", "Rössler attractor (a, b, c)"),
        ],
        default='LORENZ'
    )

    attractor_steps: IntProperty(
        name="Steps",
        default=20000,
        min=100,
        max=200000,
        description="Number of integration steps"
    )

    attractor_dt: FloatProperty(
        name="dt",
        default=0.01,
        min=1e-5,
        max=0.1,
        description="Time step for integration (smaller = smoother, slower)"
    )

    attractor_x0: FloatProperty(name="x0", default=0.0)
    attractor_y0: FloatProperty(name="y0", default=1.0)
    attractor_z0: FloatProperty(name="z0", default=1.05)

    attractor_scale: FloatProperty(
        name="Scale",
        default=0.05,
        min=0.0001,
        max=10.0,
        description="Scale factor applied to generated points"
    )


# =========================================================
# Operator
# =========================================================

class MESH_OT_generate_math_equation(Operator):
    bl_idname = "mesh.generate_math_equation"
    bl_label = "Generate Equation"
    bl_description = "Generate a 3D object from the given math equation"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.math_eq_props
        etype = props.equation_type

        if etype == 'YFX':
            return self.generate_yfx(context, props)
        elif etype == 'SURFACE':
            return self.generate_surface(context, props)
        elif etype == 'CURVE':
            return self.generate_curve(context, props)
        elif etype == 'SURFACE_PARAM':
            return self.generate_param_surface(context, props)
        elif etype == 'IMPLICIT':
            return self.generate_implicit_points(context, props)
        elif etype == 'IMPLICIT_MC':
            return self.generate_implicit_mc(context, props)
        elif etype == 'ATTRACTOR':
            return self.generate_attractor(context, props)
        else:
            self.report({'ERROR'}, "Unknown equation type")
            return {'CANCELLED'}

    # ---------- Graph y=f(x) ----------
    def generate_yfx(self, context, props):
        x_min, x_max = props.x_min, props.x_max
        n = props.res_x

        if x_max == x_min or n < 2:
            self.report({'ERROR'}, "Invalid range or resolution")
            return {'CANCELLED'}

        dx = (x_max - x_min) / (n - 1)
        points = []

        try:
            for i in range(n):
                x = x_min + i * dx
                z_val = eval_expr(props.yfx_eq, **locals_with_params(props, x=x))
                points.append((float(x), 0.0, float(z_val)))
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        curve_data = bpy.data.curves.new("Graph_yfx", type='CURVE')
        curve_data.dimensions = '3D'
        spline = curve_data.splines.new('POLY')
        spline.points.add(len(points) - 1)

        for i, (x, y, z) in enumerate(points):
            spline.points[i].co = (x, y, z, 1.0)

        obj = bpy.data.objects.new("Graph_yfx", curve_data)
        context.collection.objects.link(obj)
        context.view_layer.objects.active = obj
        obj.select_set(True)
        return {'FINISHED'}

    # ---------- Surface z=f(x,y) ----------
    def generate_surface(self, context, props):
        x_min, x_max = props.x_min, props.x_max
        y_min, y_max = props.y_min, props.y_max
        nx, ny = props.res_x, props.res_y

        if x_max == x_min or y_max == y_min:
            self.report({'ERROR'}, "X/Y range cannot be zero")
            return {'CANCELLED'}

        dx = (x_max - x_min) / nx
        dy = (y_max - y_min) / ny

        verts = []
        faces = []

        try:
            for i in range(nx + 1):
                x = x_min + i * dx
                for j in range(ny + 1):
                    y = y_min + j * dy
                    z = eval_expr(props.surface_eq, **locals_with_params(props, x=x, y=y))
                    verts.append((x, y, float(z)))
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        for i in range(nx):
            for j in range(ny):
                v0 = i * (ny + 1) + j
                v1 = v0 + 1
                v2 = v0 + (ny + 1) + 1
                v3 = v0 + (ny + 1)
                faces.append((v0, v1, v2, v3))

        mesh = bpy.data.meshes.new("MathSurface")
        mesh.from_pydata(verts, [], faces)
        mesh.update()

        obj = bpy.data.objects.new("MathSurface", mesh)
        context.collection.objects.link(obj)
        context.view_layer.objects.active = obj
        obj.select_set(True)
        return {'FINISHED'}

    # ---------- Parametric curve ----------
    def generate_curve(self, context, props):
        u_min, u_max = props.u_min, props.u_max
        nu = props.res_u

        if u_max == u_min or nu < 2:
            self.report({'ERROR'}, "Invalid u range or resolution")
            return {'CANCELLED'}

        du = (u_max - u_min) / (nu - 1)
        points = []

        try:
            for i in range(nu):
                u = u_min + i * du
                x = eval_expr(props.curve_x, **locals_with_params(props, u=u))
                y = eval_expr(props.curve_y, **locals_with_params(props, u=u))
                z = eval_expr(props.curve_z, **locals_with_params(props, u=u))
                points.append((float(x), float(y), float(z)))
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        curve_data = bpy.data.curves.new("MathCurve", type='CURVE')
        curve_data.dimensions = '3D'
        spline = curve_data.splines.new('POLY')
        spline.points.add(len(points) - 1)

        for i, (x, y, z) in enumerate(points):
            spline.points[i].co = (x, y, z, 1.0)

        obj = bpy.data.objects.new("MathCurve", curve_data)
        context.collection.objects.link(obj)
        context.view_layer.objects.active = obj
        obj.select_set(True)
        return {'FINISHED'}

    # ---------- Parametric surface ----------
    def generate_param_surface(self, context, props):
        u_min, u_max = props.u_min, props.u_max
        v_min, v_max = props.v_min, props.v_max
        nu, nv = props.res_u, props.res_v

        if u_max == u_min or v_max == v_min:
            self.report({'ERROR'}, "u/v range cannot be zero")
            return {'CANCELLED'}

        du = (u_max - u_min) / nu
        dv = (v_max - v_min) / nv

        verts = []
        faces = []

        try:
            for i in range(nu + 1):
                u = u_min + i * du
                for j in range(nv + 1):
                    v = v_min + j * dv
                    x = eval_expr(props.surf_param_x, **locals_with_params(props, u=u, v=v))
                    y = eval_expr(props.surf_param_y, **locals_with_params(props, u=u, v=v))
                    z = eval_expr(props.surf_param_z, **locals_with_params(props, u=u, v=v))
                    verts.append((float(x), float(y), float(z)))
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        for i in range(nu):
            for j in range(nv):
                v0 = i * (nv + 1) + j
                v1 = v0 + 1
                v2 = v0 + (nv + 1) + 1
                v3 = v0 + (nv + 1)
                faces.append((v0, v1, v2, v3))

        mesh = bpy.data.meshes.new("ParamSurface")
        mesh.from_pydata(verts, [], faces)
        mesh.update()

        obj = bpy.data.objects.new("ParamSurface", mesh)
        context.collection.objects.link(obj)
        context.view_layer.objects.active = obj
        obj.select_set(True)
        return {'FINISHED'}

    # ---------- Implicit F(x,y,z)=0 -> points ----------
    def generate_implicit_points(self, context, props):
        x_min, x_max = props.x_min, props.x_max
        y_min, y_max = props.y_min, props.y_max
        z_min, z_max = props.z_min, props.z_max
        nx, ny, nz = props.res_x, props.res_y, props.res_z
        eps = props.iso_threshold

        if x_max == x_min or y_max == y_min or z_max == z_min:
            self.report({'ERROR'}, "X/Y/Z range cannot be zero")
            return {'CANCELLED'}

        dx = (x_max - x_min) / nx
        dy = (y_max - y_min) / ny
        dz = (z_max - z_min) / nz

        verts = []

        try:
            for i in range(nx + 1):
                x = x_min + i * dx
                for j in range(ny + 1):
                    y = y_min + j * dy
                    for k in range(nz + 1):
                        z = z_min + k * dz
                        val = eval_expr(props.implicit_eq, **locals_with_params(props, x=x, y=y, z=z))
                        if abs(val) <= eps:
                            verts.append((x, y, z))
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        if not verts:
            self.report({'WARNING'}, "No points near surface. Increase ε or change ranges.")
            return {'CANCELLED'}

        mesh = bpy.data.meshes.new("ImplicitPoints")
        mesh.from_pydata(verts, [], [])
        mesh.update()

        obj = bpy.data.objects.new("ImplicitPoints", mesh)
        context.collection.objects.link(obj)
        context.view_layer.objects.active = obj
        obj.select_set(True)
        return {'FINISHED'}

    # ---------- Implicit marching cubes ----------
    def generate_implicit_mc(self, context, props):
        if props.res_x * props.res_y * props.res_z > 200_000:
            self.report({'WARNING'}, "High resolution, may be slow.")

        x_min, x_max = props.x_min, props.x_max
        y_min, y_max = props.y_min, props.y_max
        z_min, z_max = props.z_min, props.z_max
        nx, ny, nz = props.res_x, props.res_y, props.res_z
        iso = props.iso_mc_level

        if x_max == x_min or y_max == y_min or z_max == z_min:
            self.report({'ERROR'}, "X/Y/Z range cannot be zero")
            return {'CANCELLED'}

        dx = (x_max - x_min) / nx
        dy = (y_max - y_min) / ny
        dz = (z_max - z_min) / nz

        def index(i, j, k):
            return i * (ny + 1) * (nz + 1) + j * (nz + 1) + k

        values = [0.0] * ((nx + 1) * (ny + 1) * (nz + 1))

        try:
            for i in range(nx + 1):
                x = x_min + i * dx
                for j in range(ny + 1):
                    y = y_min + j * dy
                    for k in range(nz + 1):
                        z = z_min + k * dz
                        v = eval_expr(props.implicit_eq, **locals_with_params(props, x=x, y=y, z=z))
                        values[index(i, j, k)] = float(v)
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        verts = []
        faces = []

        for i in range(nx):
            x = x_min + i * dx
            for j in range(ny):
                y = y_min + j * dy
                for k in range(nz):
                    z = z_min + k * dz

                    p = [
                        (x,       y,       z),
                        (x + dx,  y,       z),
                        (x + dx,  y + dy,  z),
                        (x,       y + dy,  z),
                        (x,       y,       z + dz),
                        (x + dx,  y,       z + dz),
                        (x + dx,  y + dy,  z + dz),
                        (x,       y + dy,  z + dz),
                    ]

                    val = [
                        values[index(i,     j,     k)],
                        values[index(i + 1, j,     k)],
                        values[index(i + 1, j + 1, k)],
                        values[index(i,     j + 1, k)],
                        values[index(i,     j,     k + 1)],
                        values[index(i + 1, j,     k + 1)],
                        values[index(i + 1, j + 1, k + 1)],
                        values[index(i,     j + 1, k + 1)],
                    ]

                    cubeindex = 0
                    if val[0] < iso: cubeindex |= 1
                    if val[1] < iso: cubeindex |= 2
                    if val[2] < iso: cubeindex |= 4
                    if val[3] < iso: cubeindex |= 8
                    if val[4] < iso: cubeindex |= 16
                    if val[5] < iso: cubeindex |= 32
                    if val[6] < iso: cubeindex |= 64
                    if val[7] < iso: cubeindex |= 128

                    if EDGE_TABLE[cubeindex] == 0:
                        continue

                    vert_list = [None] * 12
                    edge_mask = EDGE_TABLE[cubeindex]

                    if edge_mask & 1:
                        vert_list[0] = vertex_interp(iso, p[0], p[1], val[0], val[1])
                    if edge_mask & 2:
                        vert_list[1] = vertex_interp(iso, p[1], p[2], val[1], val[2])
                    if edge_mask & 4:
                        vert_list[2] = vertex_interp(iso, p[2], p[3], val[2], val[3])
                    if edge_mask & 8:
                        vert_list[3] = vertex_interp(iso, p[3], p[0], val[3], val[0])
                    if edge_mask & 16:
                        vert_list[4] = vertex_interp(iso, p[4], p[5], val[4], val[5])
                    if edge_mask & 32:
                        vert_list[5] = vertex_interp(iso, p[5], p[6], val[5], val[6])
                    if edge_mask & 64:
                        vert_list[6] = vertex_interp(iso, p[6], p[7], val[6], val[7])
                    if edge_mask & 128:
                        vert_list[7] = vertex_interp(iso, p[7], p[4], val[7], val[4])
                    if edge_mask & 256:
                        vert_list[8] = vertex_interp(iso, p[0], p[4], val[0], val[4])
                    if edge_mask & 512:
                        vert_list[9] = vertex_interp(iso, p[1], p[5], val[1], val[5])
                    if edge_mask & 1024:
                        vert_list[10] = vertex_interp(iso, p[2], p[6], val[2], val[6])
                    if edge_mask & 2048:
                        vert_list[11] = vertex_interp(iso, p[3], p[7], val[3], val[7])

                    tri_row = TRI_TABLE[cubeindex]
                    for t in range(0, 16, 3):
                        if tri_row[t] == -1:
                            break
                        a = tri_row[t]
                        b = tri_row[t + 1]
                        c_ = tri_row[t + 2]
                        va = vert_list[a]
                        vb = vert_list[b]
                        vc = vert_list[c_]
                        if va is None or vb is None or vc is None:
                            continue
                        idx0 = len(verts)
                        verts.append(va)
                        verts.append(vb)
                        verts.append(vc)
                        faces.append((idx0, idx0 + 1, idx0 + 2))

        if not verts:
            self.report({'WARNING'}, "No triangles generated. Check iso level / ranges / res.")
            return {'CANCELLED'}

        mesh = bpy.data.meshes.new("ImplicitMC")
        mesh.from_pydata(verts, [], faces)
        mesh.update()

        obj = bpy.data.objects.new("ImplicitMC", mesh)
        context.collection.objects.link(obj)
        context.view_layer.objects.active = obj
        obj.select_set(True)
        return {'FINISHED'}

    # ---------- Strange attractors ----------
    def generate_attractor(self, context, props):
        steps = props.attractor_steps
        dt = props.attractor_dt

        if steps <= 0 or dt <= 0.0:
            self.report({'ERROR'}, "Steps and dt must be positive")
            return {'CANCELLED'}

        x = props.attractor_x0
        y = props.attractor_y0
        z = props.attractor_z0

        a = props.param_a
        b = props.param_b
        c = props.param_c

        points = []
        warmup = min(1000, steps // 10)  # چند صد گام اول را ذخیره نکنیم تا attractor جا بیفته

        for i in range(steps):
            if props.attractor_type == 'LORENZ':
                # Lorenz:
                # dx/dt = a (y - x)
                # dy/dt = x (b - z) - y
                # dz/dt = x y - c z
                dx = a * (y - x)
                dy = x * (b - z) - y
                dz = x * y - c * z

            elif props.attractor_type == 'ROSSLER':
                # Rössler:
                # dx/dt = -y - z
                # dy/dt = x + a y
                # dz/dt = b + z (x - c)
                dx = -y - z
                dy = x + a * y
                dz = b + z * (x - c)

            else:
                self.report({'ERROR'}, "Unknown attractor type")
                return {'CANCELLED'}

            x += dx * dt
            y += dy * dt
            z += dz * dt

            if i >= warmup:
                points.append((x, y, z))

        if not points:
            self.report({'WARNING'}, "No points generated for attractor")
            return {'CANCELLED'}

        scale = props.attractor_scale
        if scale != 1.0:
            points = [(px * scale, py * scale, pz * scale) for (px, py, pz) in points]

        curve_data = bpy.data.curves.new(f"{props.attractor_type}_Attractor", type='CURVE')
        curve_data.dimensions = '3D'
        spline = curve_data.splines.new('POLY')
        spline.points.add(len(points) - 1)

        for i, (px, py, pz) in enumerate(points):
            spline.points[i].co = (px, py, pz, 1.0)

        obj = bpy.data.objects.new(f"{props.attractor_type}_Attractor", curve_data)
        context.collection.objects.link(obj)
        context.view_layer.objects.active = obj
        obj.select_set(True)
        return {'FINISHED'}


# =========================================================
# UI Panel
# =========================================================

class VIEW3D_PT_math_equations(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Math 3D'
    bl_label = "Math Equations"

    def draw(self, context):
        layout = self.layout
        props = context.scene.math_eq_props

        layout.prop(props, "equation_type", expand=True)
        etype = props.equation_type

        if etype == 'YFX':
            box = layout.box()
            box.label(text="Graph y = f(x)")
            box.prop(props, "yfx_eq", text="f(x) =")
            row = box.row(align=True)
            row.prop(props, "x_min")
            row.prop(props, "x_max")
            box.prop(props, "res_x", text="Resolution")
            box.label(text="Drawn as (x, 0, f(x)) in XZ plane")

        elif etype == 'SURFACE':
            box = layout.box()
            box.label(text="Surface z = f(x, y)")
            box.prop(props, "surface_eq", text="z =")
            row = box.row(align=True)
            row.prop(props, "x_min")
            row.prop(props, "x_max")
            row = box.row(align=True)
            row.prop(props, "y_min")
            row.prop(props, "y_max")
            row = box.row(align=True)
            row.prop(props, "res_x")
            row.prop(props, "res_y")

        elif etype == 'CURVE':
            box = layout.box()
            box.label(text="Parametric Curve")
            box.prop(props, "curve_x", text="x(u) =")
            box.prop(props, "curve_y", text="y(u) =")
            box.prop(props, "curve_z", text="z(u) =")
            row = box.row(align=True)
            row.prop(props, "u_min")
            row.prop(props, "u_max")
            box.prop(props, "res_u")

        elif etype == 'SURFACE_PARAM':
            box = layout.box()
            box.label(text="Parametric Surface")
            box.prop(props, "surf_param_x", text="x(u,v) =")
            box.prop(props, "surf_param_y", text="y(u,v) =")
            box.prop(props, "surf_param_z", text="z(u,v) =")
            row = box.row(align=True)
            row.prop(props, "u_min")
            row.prop(props, "u_max")
            row = box.row(align=True)
            row.prop(props, "v_min")
            row.prop(props, "v_max")
            row = box.row(align=True)
            row.prop(props, "res_u", text="Res U")
            row.prop(props, "res_v", text="Res V")

        elif etype == 'IMPLICIT':
            box = layout.box()
            box.label(text="Implicit Surface (Point Cloud)")
            box.prop(props, "implicit_eq", text="F =")
            row = box.row(align=True)
            row.prop(props, "x_min")
            row.prop(props, "x_max")
            row = box.row(align=True)
            row.prop(props, "y_min")
            row.prop(props, "y_max")
            row = box.row(align=True)
            row.prop(props, "z_min")
            row.prop(props, "z_max")
            row = box.row(align=True)
            row.prop(props, "res_x")
            row.prop(props, "res_y")
            row.prop(props, "res_z")
            box.prop(props, "iso_threshold")
            box.label(text="Points with |F| <= ε are created")

        elif etype == 'IMPLICIT_MC':
            box = layout.box()
            box.label(text="Implicit Surface (Marching Cubes)")
            box.prop(props, "implicit_eq", text="F =")
            box.prop(props, "iso_mc_level", text="Iso level")
            row = box.row(align=True)
            row.prop(props, "x_min")
            row.prop(props, "x_max")
            row = box.row(align=True)
            row.prop(props, "y_min")
            row.prop(props, "y_max")
            row = box.row(align=True)
            row.prop(props, "z_min")
            row.prop(props, "z_max")
            row = box.row(align=True)
            row.prop(props, "res_x")
            row.prop(props, "res_y")
            row.prop(props, "res_z")
            box.label(text="Warning: High resolution can be slow")

        elif etype == 'ATTRACTOR':
            box = layout.box()
            box.label(text="Strange Attractor")
            box.prop(props, "attractor_type", text="Type")
            row = box.row(align=True)
            row.prop(props, "attractor_steps")
            row.prop(props, "attractor_dt")
            row = box.row(align=True)
            row.prop(props, "attractor_x0")
            row.prop(props, "attractor_y0")
            row.prop(props, "attractor_z0")
            box.prop(props, "attractor_scale")
            box.label(text="Use a, b, c below as system parameters")
            if props.attractor_type == 'LORENZ':
                box.label(text="Lorenz: a=σ, b=ρ, c=β  (default 10, 28, 2.667)")
            elif props.attractor_type == 'ROSSLER':
                box.label(text="Rössler: a, b, c  (typical 0.2, 0.2, 5.7)")

        layout.separator()
        param_box = layout.box()
        param_box.label(text="Parameters a, b, c")
        row = param_box.row(align=True)
        row.prop(props, "param_a")
        row.prop(props, "param_b")
        row.prop(props, "param_c")

        layout.separator()
        layout.operator("mesh.generate_math_equation", icon='MESH_GRID')


# =========================================================
# Registration
# =========================================================

classes = (
    MathEquationProperties,
    MESH_OT_generate_math_equation,
    VIEW3D_PT_math_equations,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.math_eq_props = bpy.props.PointerProperty(type=MathEquationProperties)


def unregister():
    del bpy.types.Scene.math_eq_props
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
